# Design System Specification: The Botanical Atelier

## 1. Overview & Creative North Star
**Creative North Star: "The Digital Conservatory"**

This design system is not a mere e-commerce framework; it is a curated editorial experience. It seeks to bridge the gap between the organic irregularities of nature and the precision of high-end luxury. To move beyond "standard" webshops, we employ **Organic Brutalism**—a style defined by bold, intentional whitespace, asymmetrical image placements, and a refusal to use traditional structural lines.

The layout should feel like a premium coffee-table book. Elements should overlap slightly to create depth, and high-quality photography must be treated as a primary structural component rather than an afterthought. By utilizing "The Layering Principle," we replace rigid grids with a fluid, breathable environment that invites the user to linger.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule

The palette is rooted in a "Deep Forest" spectrum, using tonal shifts to guide the eye.

### Primary Palette (Functional)
*   **Primary (`#061b0e`):** Our "Deep Forest." Used for high-impact text and foundational branding.
*   **Secondary (`#3b6934`):** The "Lush Leaf." Used for interactive elements and subtle highlights.
*   **Tertiary (`#031d02`):** The "Undergrowth." Used for deep accents and heavy contrast.
*   **Surface Tint (`#4d6453`):** Used for glassmorphic overlays and subtle brand presence.

### The "No-Line" Rule
To maintain a premium, editorial feel, **1px solid borders are strictly prohibited for sectioning.** 
*   **Boundaries:** Define changes in content by shifting from `surface` (#fcf9f8) to `surface-container-low` (#f6f3f2).
*   **Hierarchy:** Use the `surface-container` tiers (Lowest to Highest) to create nested depth. A card should not have a border; it should simply exist as a `surface-container-lowest` (#ffffff) element on a `surface-container` (#f0edec) background.

### The "Glass & Gradient" Rule
For main CTAs and hero backgrounds, avoid flat fills. Use a subtle linear gradient from `primary` (#061b0e) to `primary_container` (#1b3022) at a 135-degree angle. For floating navigation or modals, apply **Glassmorphism**:
*   **Fill:** `surface_variant` at 70% opacity.
*   **Effect:** `backdrop-blur: 20px`.
*   **Edge:** A "Ghost Border" (see Section 4).

---

## 3. Typography: Sophisticated Editorial

We use a high-contrast scale to mirror the hierarchy of a luxury magazine.

*   **Display (`notoSerif`):** Used for heroic statements. Set with tight letter-spacing (-0.02em) to feel authoritative.
*   **Headline (`notoSerif`):** Reserved for product names and section headers. These should often be placed with intentional asymmetry (e.g., hanging off the grid).
*   **Body (`inter`):** The workhorse. Always prioritize legibility. `body-lg` (1rem) is the standard for product descriptions to maintain a premium feel.
*   **Labels (`inter`):** Set in `label-md` or `label-sm`. Use all-caps with increased letter-spacing (+0.05em) for category tags or "Sale" badges to create a distinct functional contrast.

---

## 4. Elevation & Depth

We eschew traditional material shadows in favor of **Tonal Layering**.

### The Layering Principle
Depth is achieved by stacking the `surface-container` tokens:
1.  **Level 0 (Base):** `surface` (#fcf9f8)
2.  **Level 1 (Sections):** `surface-container-low` (#f6f3f2)
3.  **Level 2 (Cards/Modules):** `surface-container-lowest` (#ffffff)
4.  **Level 3 (Pop-overs):** `surface-container-highest` (#e5e2e1)

### Ambient Shadows
When an element must "float" (e.g., the Chat FAB), use an **Ambient Shadow**:
*   **Color:** `on-surface` (#1c1b1b) at 4%–6% opacity.
*   **Blur:** 40px to 60px.
*   **Spread:** -5px (to keep the shadow tucked and soft).

### The "Ghost Border"
If accessibility requires a boundary, use the `outline-variant` (#c3c8c1) at **15% opacity**. This creates a suggestion of a container without breaking the "No-Line" rule.

---

## 5. Components

### Buttons
*   **Primary:** Fill with `primary` (#061b0e), text in `on-primary` (#ffffff). Shape: `md` (0.75rem/12px) roundedness.
*   **Secondary:** Fill with `secondary_container` (#b9eeab), text in `on-secondary_container` (#3f6d38).
*   **Tertiary:** No background. Text in `primary`. Hover state uses a subtle `surface-container-high` (#ebe7e7) background shift.

### Input Fields
*   **Style:** Minimalist. No bottom line. Use `surface-container-low` (#f6f3f2) as the background fill with a `sm` (4px) corner radius.
*   **Focus State:** Shift background to `surface-container-high` and apply a 1px "Ghost Border" using `primary`.

### Cards & Lists
*   **Forbid Dividers:** Do not use lines to separate list items. Use **Vertical White Space** (Spacing Scale 6 or 8) or alternating background tints between `surface` and `surface-container-low`.
*   **Product Cards:** Use `xl` (1.5rem) roundedness for images within cards to soften the "artificial" nature of the products, making them feel more organic.

### Specialized Components
*   **The "Sale" Accent:** Use `on-secondary_container` (#3f6d38) for Sale tags. It is eye-catching but stays within the botanical family.
*   **Floating Chat FAB:** A circular button (`full` roundedness) using the `primary` fill. Use the Glassmorphism rule if positioned over imagery.

---

## 6. Do’s and Don'ts

### Do
*   **Do** use asymmetrical margins. For example, a hero image may have a 10% left margin but a 0% right margin to "bleed" off the screen.
*   **Do** utilize the `Spacing 20` (7rem) token for section padding to ensure the "Modern" breathable feel.
*   **Do** use `notoSerif` for numbers (prices) to make the cost feel like a curated value rather than a clinical transaction.

### Don’t
*   **Don't** use 100% black. Always use `on-background` (#1c1b1b) for text to maintain tonal softness.
*   **Don't** use standard "drop shadows." If it looks like a default software effect, it is too heavy.
*   **Don't** crowd the imagery. If a plant photo is beautiful, let it occupy a full `surface-container` without text overlapping the focal point.
*   **Don't** use hard corners. Even "sharp" elements should have at least the `sm` (4px) radius to maintain the organic brand identity.